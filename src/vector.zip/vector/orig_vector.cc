#include <iostream>

#include "vector"
using namespace std;
int main() {
  vector<int> a();
  a.push_back(5);
  cout << a[0] << endl;
}